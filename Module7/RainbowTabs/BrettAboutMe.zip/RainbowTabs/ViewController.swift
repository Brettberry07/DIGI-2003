//
//  ViewController.swift
//  RainbowTabs
//
//  Created by Berry, Brett A. (Student) on 10/2/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

