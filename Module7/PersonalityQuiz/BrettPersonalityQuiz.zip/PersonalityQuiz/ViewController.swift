//
//  ViewController.swift
//  PersonalityQuiz
//
//  Created by Berry, Brett A. (Student) on 10/3/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func unwindToQuizIntroduction(segue:
    UIStoryboardSegue) {
    }


}

